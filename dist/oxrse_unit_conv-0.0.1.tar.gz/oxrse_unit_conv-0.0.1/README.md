# Oxford RSE Unit Conversion

## Overview

## Structure

## Development

### Testing

#### Manual testing

#### Unit testing

### Building package

Building the package produces distribution files from the source code (that you've just updated).
This will be accompanied by an appropriate update to the semantic versioning.

```shell
python3 -m build
```

The updated files will be created in `./dist`.

## Acknowledgements

The initial setup for this python project was created following the 
[packaging tutorial](https://packaging.python.org/en/latest/tutorials/packaging-projects/).
